package com.tuling;

/**
 * @author Fox
 */
public class AgentTest {
    
    public static void main(String[] args) {
        //  TODO   启动服务 获取进程 memory  jvm
        //  Instrument  定位到UserService 统计方法执行时间
        // 微服务  引入nacos  pom jar yml
        System.out.println("hello world");
        
        // TODO业务逻辑    UserService方法  统计方法执行时间
    }
}
