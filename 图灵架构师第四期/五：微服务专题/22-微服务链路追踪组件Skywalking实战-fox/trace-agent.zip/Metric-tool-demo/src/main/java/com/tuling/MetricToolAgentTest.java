package com.tuling;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Fox
 */
public class MetricToolAgentTest {
    
    public static void main(String[] args) {
    
        boolean flag = true;
        while (flag) {
            List<Object> list = new ArrayList<Object>();
            list.add("Hello World");
        }
        
    }
    
}
