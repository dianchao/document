package bat.ke.qq.com;


public class FoxAgentTest {

    public static void main(String[] args) {
        System.out.println("main");
    }

}
