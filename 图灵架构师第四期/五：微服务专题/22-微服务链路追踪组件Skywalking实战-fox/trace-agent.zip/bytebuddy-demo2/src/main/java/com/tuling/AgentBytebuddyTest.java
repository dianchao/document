package com.tuling;


/**
 * @author Fox
 */
public class AgentBytebuddyTest {
    
    public static void main(String[] args) {
    
        HelloService helloService = new HelloService();
        helloService.say();
        helloService.say2();
    
       
    }
}
