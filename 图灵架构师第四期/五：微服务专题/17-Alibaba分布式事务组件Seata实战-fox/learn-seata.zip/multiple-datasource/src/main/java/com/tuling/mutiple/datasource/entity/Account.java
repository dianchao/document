package com.tuling.mutiple.datasource.entity;

import lombok.Data;


/**
 * @author Fox
 */
@Data
public class Account {
    private Integer id;
    
    private String userId;
    
    private Integer money;
}
