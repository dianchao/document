package com.tuling.datasource.entity;

import lombok.Data;


/**
 * @author Fox
 */
@Data
public class Account {
    private Integer id;
    
    private String userId;
    
    private Integer money;
}
