/**
 * @ngdoc function
 * @name sentinelDashboardApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the sentinelDashboardApp
 */
angular.module('sentinelDashboardApp')
  .controller('HomeCtrl', ['$scope', '$position', function ($scope, $position) {
    // do noting
  }]);
