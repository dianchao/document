package com.tuling.provider.api;

public interface HelloService {

    String sayHello(String userName);
}
