package com.roy.shardingDemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.roy.shardingDemo.entity.Dict;

/**
 * @author ：楼兰
 * @date ：Created in 2021/1/5
 * @description:
 **/
public interface DictMapper extends BaseMapper<Dict> {
}
