package com.roy.shardingDemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.roy.shardingDemo.entity.Course;

/**
 * @author ：楼兰
 * @date ：Created in 2021/1/4
 * @description:
 **/

public interface CourseMapper extends BaseMapper<Course> {
}
