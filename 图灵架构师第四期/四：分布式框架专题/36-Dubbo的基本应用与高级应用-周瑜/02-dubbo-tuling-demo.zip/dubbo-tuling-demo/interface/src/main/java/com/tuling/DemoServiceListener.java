package com.tuling;

public interface DemoServiceListener {
    void changed(String msg);
}
