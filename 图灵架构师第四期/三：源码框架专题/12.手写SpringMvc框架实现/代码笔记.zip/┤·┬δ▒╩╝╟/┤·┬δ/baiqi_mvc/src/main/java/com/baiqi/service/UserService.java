package com.baiqi.service;

import com.baiqi.bean.User;

/**
 * @author 白起老师
 */
public interface UserService {

     public  void  findUser();

     public User getUser();
}
