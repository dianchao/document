const getters = {
      token: state => state.user.token,
      memberId: state => state.user.memberId,
      nickName: state => state.user.nickName
}
export default getters